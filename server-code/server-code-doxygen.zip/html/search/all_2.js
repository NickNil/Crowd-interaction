var searchData=
[
  ['calculate',['calculate',['../class_score_calculation.html#ab28ba29fd8aa05dee42ecba7c479788a',1,'ScoreCalculation']]]
];
