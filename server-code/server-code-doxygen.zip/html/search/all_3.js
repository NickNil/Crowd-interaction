var searchData=
[
  ['database',['database',['../class_mongo_connection.html#a67db435ba7d50e949aab9b008f461b34',1,'MongoConnection']]]
];
