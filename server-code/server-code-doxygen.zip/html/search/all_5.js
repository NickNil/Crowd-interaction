var searchData=
[
  ['insert_5fevent',['insert_event',['../class_event.html#aa4eb3e98e60455bd21f0dae6725b9bf4',1,'Event']]]
];
