var searchData=
[
  ['mongoconnection',['MongoConnection',['../class_mongo_connection.html',1,'']]]
];
