var searchData=
[
  ['score',['Score',['../class_score.html',1,'']]],
  ['scorecalculation',['ScoreCalculation',['../class_score_calculation.html',1,'']]],
  ['set_5fevent_5finfo',['set_event_info',['../class_event.html#af3ede097342273c9ca807aa633ca7d12',1,'Event']]],
  ['set_5fuser_5fdata',['set_user_data',['../class_user.html#a1a5a367f7f457f0d7a9d00aab7bf92af',1,'User']]],
  ['store_5fin_5fdatabase',['store_in_database',['../class_user.html#a3dd0ac2c5e6f3104240bad99eb677eeb',1,'User']]]
];
